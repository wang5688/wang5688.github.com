#获取歌曲url
http://cs003.m2828.com/apis/getKugouSong.php
    params : hash

#获取歌词
http://cs003.m2828.com/apis/getLrc.php
    params : hash
