<template lang="html">
    <div>
        this is list
    </div>
</template>

<script>
export default {
}
</script>

<style lang="css">
</style>
