<template lang="html">
    <div>
        this is singer
    </div>
</template>

<script>
export default {
}
</script>

<style lang="css">
</style>
